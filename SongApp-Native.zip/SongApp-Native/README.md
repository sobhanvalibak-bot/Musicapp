# SongApp Native (Kotlin + Jetpack Compose)
اپ نیتیو (بدون WebView) که مستقیم از api.php سرور داده می‌گیرد.

امکانات: ورود/ثبت‌نام، آهنگ‌ها و پلیر پس‌زمینه، لایک/کامنت، جستجوی آهنگ و کاربر،
استوری (دیدن/ساخت/حذف)، پروفایل (ویرایش، فالو، آپلود)، NFT (کیف پول، خرید گیفت،
ارتقا، فروش/خرید در مارکت، انتقال، پین و نشان پروفایل) با انیمیشن Lottie.

## ساخت APK
1) پروژه را در GitHub آپلود کن → Actions → Build APK → Run workflow → app-debug.apk از Artifacts.
2) یا Android Studio → Build > Build APK(s).

آدرس سرور: app/build.gradle → SERVER_URL
