package ct.songapp

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

class PlayerUi {
    var controller: MediaController? = null
    var playing by mutableStateOf(false)
    var currentId by mutableStateOf<String?>(null)
    var pos by mutableLongStateOf(0L)
    var dur by mutableLongStateOf(0L)

    private val listener = object : Player.Listener {
        override fun onEvents(p: Player, e: Player.Events) {
            playing = p.isPlaying
            currentId = p.currentMediaItem?.mediaId
            dur = p.duration.coerceAtLeast(0L)
            pos = p.currentPosition
        }
    }

    fun attach(c: MediaController) {
        controller = c
        c.addListener(listener)
        playing = c.isPlaying
        currentId = c.currentMediaItem?.mediaId
        tick()
    }

    fun detach() {
        controller?.removeListener(listener)
        controller = null
    }

    fun tick() {
        controller?.let { pos = it.currentPosition; dur = it.duration.coerceAtLeast(0L) }
    }

    private fun Song.item() = MediaItem.Builder()
        .setMediaId(id).setUri(url)
        .setMediaMetadata(
            MediaMetadata.Builder().setTitle(title).setArtist(artist).setAlbumTitle(album)
                .setArtworkUri(if (cover.isNotEmpty()) Uri.parse(cover) else null).build()
        ).build()

    fun playList(list: List<Song>, index: Int) {
        val c = controller ?: return
        c.setMediaItems(list.map { it.item() }, index, 0L)
        c.prepare(); c.play()
    }

    fun toggle() { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
    fun next() { controller?.seekToNextMediaItem() }
    fun prev() {
        controller?.let { if (it.currentPosition > 3000) it.seekTo(0) else it.seekToPreviousMediaItem() }
    }
    fun seek(ms: Long) { controller?.seekTo(ms); pos = ms }
    fun stop() { controller?.run { stop(); clearMediaItems() }; currentId = null }
}

class MainVM(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("music", 0)
    val player = PlayerUi()

    var token by mutableStateOf<String?>(null)
    var me by mutableStateOf<User?>(null)
    var songs by mutableStateOf<List<Song>>(emptyList())
    var users by mutableStateOf<List<User>>(emptyList())
    var stories by mutableStateOf<List<Story>>(emptyList())
    var loading by mutableStateOf(false)
    var booting by mutableStateOf(true)
    var busy by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var toast by mutableStateOf<String?>(null)

    // NFT
    var coins by mutableIntStateOf(0)
    var collections by mutableStateOf<List<NftCollection>>(emptyList())
    var inventory by mutableStateOf<List<Nft>>(emptyList())
    var market by mutableStateOf<List<Nft>>(emptyList())
    var nftLoading by mutableStateOf(false)

    init {
        token = prefs.getString("token", null)
        Net.token = token
        viewModelScope.launch { boot() }
    }

    fun userById(id: String): User? = if (me?.id == id) me else users.firstOrNull { it.id == id }

    private suspend fun boot() {
        runCatching { Api.call("GET", "/ping") }   // کوکی چالش هاست را از قبل می‌گیرد
        if (token != null) {
            try {
                me = Api.obj("GET", "/me").getJSONObject("me").user()
                loadFeed()
            } catch (e: ApiException) {
                if (e.code == 401) clearSession() else toast = e.message
            } catch (e: Exception) {
                toast = e.message
            }
        }
        booting = false
    }

    private suspend fun loadFeed() {
        loading = true
        try {
            val j = Api.obj("GET", "/feed")
            songs = j.getJSONArray("songs").list { it.song() }
            users = j.optJSONArray("users")?.list { it.user() } ?: emptyList()
            stories = j.optJSONArray("stories")?.list { it.story() } ?: emptyList()
            j.optJSONObject("me")?.let { me = it.user() }
        } finally {
            loading = false
        }
    }

    fun refresh() {
        viewModelScope.launch { try { loadFeed() } catch (e: Exception) { toast = e.message } }
    }

    private fun act(ok: String? = null, block: suspend () -> Unit) {
        viewModelScope.launch {
            busy = true
            try { block(); ok?.let { toast = it } } catch (e: Exception) { toast = e.message } finally { busy = false }
        }
    }

    // ---------------- auth ----------------
    fun auth(signup: Boolean, u: String, p: String) {
        viewModelScope.launch {
            busy = true; error = null
            try {
                val j = Api.obj("POST", if (signup) "/signup" else "/login", JSONObject().put("u", u).put("p", p))
                token = j.getString("token"); Net.token = token
                prefs.edit().putString("token", token).apply()
                me = j.getJSONObject("me").user()
                loadFeed()
            } catch (e: Exception) {
                error = e.message
            } finally {
                busy = false
            }
        }
    }

    private fun clearSession() {
        token = null; Net.token = null; me = null
        prefs.edit().remove("token").apply()
    }

    fun logout() {
        viewModelScope.launch { runCatching { Api.call("POST", "/logout") } }
        player.stop()
        clearSession()
    }

    // ---------------- songs ----------------
    private fun upd(id: String, f: (Song) -> Song) { songs = songs.map { if (it.id == id) f(it) else it } }

    fun toggleLike(s: Song) {
        viewModelScope.launch {
            try {
                val j = Api.obj("POST", "/like/songs/${s.id}")
                upd(s.id) { it.copy(liked = j.getBoolean("me"), likes = j.getInt("n")) }
            } catch (e: Exception) { toast = e.message }
        }
    }

    fun play(list: List<Song>, index: Int) {
        if (index < 0 || index >= list.size) return
        player.playList(list, index)
        viewModelScope.launch { runCatching { Api.call("POST", "/play/${list[index].id}") } }
    }

    suspend fun comments(id: String): List<Comment> {
        val a = Api.call("GET", "/comments/songs/$id") as JSONArray
        return List(a.length()) {
            val o = a.getJSONObject(it)
            Comment(o.optString("id"), o.optString("u"), o.optString("text"))
        }
    }

    fun postComment(id: String, text: String, done: () -> Unit) {
        viewModelScope.launch {
            try {
                val j = Api.obj("POST", "/comments/songs/$id", JSONObject().put("text", text))
                upd(id) { it.copy(comments = j.optInt("n", it.comments + 1)) }
                done()
            } catch (e: Exception) { toast = e.message }
        }
    }

    fun upload(uri: Uri) = act("آپلود شد ✓") {
        Api.uploadSong(getApplication(), uri)
        loadFeed()
    }

    // ---------------- profile ----------------
    fun saveProfile(display: String, bio: String, avatar: Uri?, banner: Uri?) = act("ذخیره شد ✓") {
        val files = mutableMapOf<String, Uri>()
        avatar?.let { files["avatar"] = it }
        banner?.let { files["banner"] = it }
        val j = Api.form(
            getApplication(), "/profile",
            mapOf("display" to display, "bio" to bio, "emoji" to (me?.emoji ?: "")), files,
        )
        me = j.getJSONObject("me").user()
        loadFeed()
    }

    fun toggleFollow(u: User) {
        viewModelScope.launch {
            try {
                val j = Api.obj("POST", "/follow/${u.id}")
                users = users.map { if (it.id == u.id) it.copy(fme = j.getBoolean("me"), followers = j.getInt("n")) else it }
            } catch (e: Exception) { toast = e.message }
        }
    }

    // ---------------- stories ----------------
    fun addStory(uri: Uri, text: String) = act("استوری ثبت شد ✓") {
        Api.form(getApplication(), "/story", mapOf("text" to text, "h" to "270"), mapOf("file" to uri))
        loadFeed()
    }

    fun deleteStory(id: String) = act("حذف شد") {
        Api.call("DELETE", "/story/$id")
        loadFeed()
    }

    // ---------------- NFT ----------------
    private suspend fun <T> quiet(f: suspend () -> T): T? =
        try { f() } catch (e: CancellationException) { throw e } catch (e: Exception) { null }

    private suspend fun reloadNft() {
        nftLoading = true
        val w = quiet { Api.obj("GET", "/nft/wallet").optInt("coins") }
        val c = quiet { (Api.call("GET", "/nft/collections") as JSONArray).list { it.collection() } }
        val inv = quiet { Api.obj("GET", "/nft/inventory").getJSONArray("items").list { it.nft() } }
        val m = quiet { Api.obj("GET", "/nft/store/new").getJSONArray("items").list { it.nft() } }
        w?.let { coins = it }; c?.let { collections = it }; inv?.let { inventory = it }; m?.let { market = it }
        if (w == null && c == null && inv == null) toast = "سرویس NFT در دسترس نیست"
        nftLoading = false
    }

    fun loadNft() { viewModelScope.launch { reloadNft() } }

    suspend fun publicNfts(uid: String): List<Nft> =
        Api.obj("GET", "/nft/public-inventory/$uid").getJSONArray("items").list { it.nft() }

    fun buyRaw(c: NftCollection) = act("خرید انجام شد ✓") {
        val j = Api.obj("POST", "/nft/buy", JSONObject().put("collection_id", c.id).put("count", 1))
        coins = j.optInt("coins_remaining", coins)
        reloadNft()
    }

    fun upgrade(n: Nft) = act("ارتقا یافت ✓") {
        Api.obj("POST", "/nft/upgrade/${n.id}")
        reloadNft()
    }

    fun listNft(n: Nft, price: Int) = act(if (price > 0) "برای فروش گذاشته شد ✓" else "از فروش برداشته شد") {
        Api.obj("POST", "/nft/list", JSONObject().put("instance_id", n.id).put("price", price))
        reloadNft()
    }

    fun transfer(n: Nft, toUser: String) = act("منتقل شد ✓") {
        Api.obj("POST", "/nft/transfer", JSONObject().put("instance_id", n.id).put("to_user_id", toUser))
        reloadNft()
    }

    fun buyListing(n: Nft) = act("خرید انجام شد ✓") {
        val j = Api.obj("POST", "/nft/buy-listing", JSONObject().put("instance_id", n.id).put("price", n.price))
        coins = j.optInt("coins_remaining", coins)
        reloadNft()
    }

    private suspend fun layout(body: JSONObject) {
        val j = Api.obj("POST", "/profile-layout", body)
        me = j.getJSONObject("me").user()
    }

    fun togglePin(n: Nft) = act {
        val cur = me?.pins ?: emptyList()
        val id = n.id.toString()
        val next = if (id in cur) cur - id else (cur + id).take(6)
        layout(JSONObject().put("pinned", JSONArray(next)))
    }

    fun toggleEquip(n: Nft) = act {
        val id = n.id.toString()
        layout(JSONObject().put("equip_id", if (me?.eq == id) "" else id))
    }
}
