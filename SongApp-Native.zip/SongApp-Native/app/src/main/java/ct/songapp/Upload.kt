package ct.songapp

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.launch

@Composable
fun UploadScreen(vm: MainVM, close: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var audio by remember { mutableStateOf<Uri?>(null) }
    var cover by remember { mutableStateOf<Uri?>(null) }
    var fileName by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var artist by remember { mutableStateOf("") }
    var album by remember { mutableStateOf("") }

    val pickAudio = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) {
            audio = u
            scope.launch {
                runCatching { Api.probe(ctx, u) }.getOrNull()?.let {
                    fileName = it.name; title = it.title; artist = it.artist; album = it.album
                }
            }
        }
    }
    val pickCover = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { if (it != null) cover = it }

    AppBackground {
        Column(Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).imePadding().padding(horizontal = 16.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(close) { Icon(Icons.Default.Close, "Close") }
                Text("Upload", fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp))
            }
            Spacer(Modifier.height(12.dp))

            // منطقه‌ی انتخاب فایل صوتی
            Box(
                Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(24.dp))
                    .background(Color(0x0FFFFFFF)).border(1.dp, P.line, RoundedCornerShape(24.dp))
                    .clickable { pickAudio.launch("audio/*") },
                Alignment.Center,
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(if (audio == null) Icons.Default.CloudUpload else Icons.Default.AudioFile, null, Modifier.size(44.dp), tint = P.soft)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        if (audio == null) "Choose an audio file" else fileName.ifBlank { "Audio selected" },
                        fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 20.dp),
                    )
                    Text(if (audio == null) "MP3, M4A, FLAC, WAV…" else "Tap to change", color = P.mute, fontSize = 13.sp)
                }
            }

            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(104.dp).clip(RoundedCornerShape(18.dp)).background(P.card2)
                        .border(1.dp, P.line, RoundedCornerShape(18.dp)).clickable { pickCover.launch("image/*") },
                    Alignment.Center,
                ) {
                    if (cover != null) AsyncImage(cover, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    else Icon(Icons.Default.AddPhotoAlternate, null, tint = P.mute, modifier = Modifier.size(32.dp))
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("Cover", fontWeight = FontWeight.Medium)
                    Text("Optional — if you skip it, the server tries to fill the cover and tags automatically.", color = P.mute, fontSize = 13.sp)
                }
            }

            Spacer(Modifier.height(18.dp))
            OutlinedTextField(title, { title = it }, Modifier.fillMaxWidth(), label = { Text("Title") }, singleLine = true, shape = RoundedCornerShape(16.dp), colors = glassFieldColors())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(artist, { artist = it }, Modifier.fillMaxWidth(), label = { Text("Artist") }, singleLine = true, shape = RoundedCornerShape(16.dp), colors = glassFieldColors())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(album, { album = it }, Modifier.fillMaxWidth(), label = { Text("Album") }, singleLine = true, shape = RoundedCornerShape(16.dp), colors = glassFieldColors())

            Spacer(Modifier.height(22.dp))
            GradButton(
                "Upload song",
                { audio?.let { a -> vm.uploadFull(a, title.trim(), artist.trim(), album.trim(), cover) { close() } } },
                Modifier.fillMaxWidth(), enabled = audio != null && !vm.busy, loading = vm.busy, icon = Icons.Default.Upload,
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}
