package ct.songapp

import org.json.JSONArray
import org.json.JSONObject

data class Song(
    val id: String, val uid: String, val title: String, val artist: String, val album: String,
    val user: String, val url: String, val cover: String, val dur: Double,
    val plays: Int, val likes: Int, val liked: Boolean, val comments: Int,
    val lyrics: String, val mine: Boolean,
)

data class User(
    val id: String, val name: String, val un: String, val avatar: String, val banner: String,
    val bio: String, val followers: Int, val following: Int, val emoji: String,
    val fme: Boolean, val pins: List<String>, val eq: String,
)

data class Story(
    val id: String, val uid: String, val user: String, val avatar: String,
    val url: String, val text: String, val mine: Boolean, val t: Long,
)

data class Nft(
    val id: Int, val num: Int, val raw: Boolean, val collection: String,
    val model: String, val symbol: String, val backdrop: String, val rawPath: String,
    val modelName: String, val symbolName: String, val backdropName: String,
    val modelPm: Int, val symbolPm: Int, val backdropPm: Int,
    val price: Int, val owner: String, val ownerName: String, val upgradeEnabled: Boolean,
)

data class NftCollection(
    val id: Int, val name: String, val price: Int, val rawPath: String,
    val upgradeEnabled: Boolean, val limit: Int, val minted: Int,
)

data class Comment(val id: String, val user: String, val text: String)

/** Android's org.json برمی‌گرداند "null" برای null — این نسخه رشته‌ی خالی می‌دهد */
fun JSONObject.str(k: String): String = if (isNull(k)) "" else optString(k)

fun abs(u: String): String = when {
    u.isEmpty() -> ""
    u.startsWith("http", true) || u.startsWith("data:") -> u
    else -> BASE + u.removePrefix("./").removePrefix("/")
}

fun JSONObject.song() = Song(
    id = getString("id"), uid = str("uid"), title = str("title"), artist = str("artist"),
    album = str("album"), user = str("u"), url = abs(str("url")),
    cover = abs(str("cover")), dur = optDouble("dur", 0.0), plays = optInt("plays"),
    likes = optInt("likes"), liked = optBoolean("me"), comments = optInt("cn"),
    lyrics = str("lyrics"), mine = optBoolean("mine"),
)

fun JSONObject.user() = User(
    id = getString("id"), name = str("name"), un = str("un"),
    avatar = abs(str("avatar")), banner = abs(str("banner")), bio = str("bio"),
    followers = optInt("followers"), following = optInt("following"), emoji = str("emoji"),
    fme = optBoolean("fme"),
    pins = optJSONArray("nftPins")?.let { a -> List(a.length()) { a.optString(it) } } ?: emptyList(),
    eq = optJSONObject("nft")?.str("id").orEmpty(),
)

fun JSONObject.story() = Story(
    id = str("id"), uid = str("uid"), user = str("u"), avatar = abs(str("ua")),
    url = abs(str("url")), text = str("text"), mine = optBoolean("mine"), t = optLong("t"),
)

fun JSONObject.nft() = Nft(
    id = optInt("id"), num = optInt("nft_num"), raw = optInt("is_raw", 1) == 1,
    collection = str("collection_name"), model = str("model_path"), symbol = str("symbol_path"),
    backdrop = str("backdrop_path"), rawPath = str("raw_path"),
    modelName = str("model_name"), symbolName = str("symbol_name"), backdropName = str("backdrop_name"),
    modelPm = optInt("model_pm"), symbolPm = optInt("symbol_pm"), backdropPm = optInt("backdrop_pm"),
    price = optInt("list_price"), owner = str("owner_id"), ownerName = str("owner_name"),
    upgradeEnabled = optInt("upgrade_enabled") == 1,
)

fun JSONObject.collection() = NftCollection(
    id = optInt("id"), name = str("name"), price = optInt("price"), rawPath = str("raw_path"),
    upgradeEnabled = optInt("upgrade_enabled") == 1, limit = optInt("raw_limit", 555),
    minted = optInt("instances_n"),
)

fun <T> JSONArray.list(f: (JSONObject) -> T): List<T> = List(length()) { f(getJSONObject(it)) }
