package ct.songapp

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory

class App : Application(), ImageLoaderFactory {
    override fun onCreate() {
        super.onCreate()
        Net.init(this)
    }

    // تصاویر هم با همان کلاینت (و کوکی چالش هاست) لود می‌شوند
    override fun newImageLoader(): ImageLoader =
        ImageLoader.Builder(this).okHttpClient(Net.client).crossfade(true).build()
}
