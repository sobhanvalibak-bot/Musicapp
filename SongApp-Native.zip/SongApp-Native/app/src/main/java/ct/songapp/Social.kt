@file:OptIn(ExperimentalMaterial3Api::class)

package ct.songapp

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

// ======================= Stories =======================

@Composable
fun StoriesRow(vm: MainVM, open: (String) -> Unit) {
    var picked by remember { mutableStateOf<Uri?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { picked = it }
    val groups = vm.stories.groupBy { it.uid }.entries.sortedByDescending { e -> e.value.maxOf { it.t } }
    LazyRow(
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { Bubble("Add story", vm.me?.avatar.orEmpty(), ring = false, plus = true) { picker.launch("image/*") } }
        items(groups, key = { it.key }) { e ->
            val s = e.value.first()
            Bubble(if (s.mine) "You" else s.user, s.avatar, ring = true, plus = false) { open(e.key) }
        }
    }
    picked?.let { uri ->
        var text by remember(uri) { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { picked = null },
            title = { Text("New story") },
            text = {
                OutlinedTextField(
                    text, { text = it.take(80) }, Modifier.fillMaxWidth(),
                    label = { Text("Caption (optional)") },
                )
            },
            confirmButton = { TextButton({ vm.addStory(uri, text.trim()); picked = null }) { Text("Share") } },
            dismissButton = { TextButton({ picked = null }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun Bubble(label: String, avatar: String, ring: Boolean, plus: Boolean, onClick: () -> Unit) {
    Column(Modifier.width(68.dp).clickable { onClick() }, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(64.dp).then(if (ring) Modifier.border(2.dp, MaterialTheme.colorScheme.primary, CircleShape) else Modifier),
            Alignment.Center,
        ) {
            Cover(avatar, Modifier.size(54.dp).clip(CircleShape))
            if (plus) Icon(Icons.Default.AddCircle, null, tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.align(Alignment.BottomEnd).size(22.dp).background(MaterialTheme.colorScheme.background, CircleShape))
        }
        Text(label, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
fun StoryViewer(vm: MainVM, uid: String, onClose: () -> Unit) {
    val list = vm.stories.filter { it.uid == uid }.sortedBy { it.t }
    if (list.isEmpty()) { LaunchedEffect(Unit) { onClose() }; return }
    var idx by remember { mutableIntStateOf(0) }
    val i = idx.coerceIn(0, list.lastIndex)
    val s = list[i]
    LaunchedEffect(i, list.size) {
        delay(5000)
        if (i < list.lastIndex) idx = i + 1 else onClose()
    }
    Box(
        Modifier.fillMaxSize().background(Color.Black).pointerInput(list.size) {
            detectTapGestures { o ->
                if (o.x < size.width / 2) { if (i > 0) idx = i - 1 }
                else if (i < list.lastIndex) idx = i + 1 else onClose()
            }
        },
    ) {
        if (s.url.isNotEmpty()) AsyncImage(s.url, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        Column(Modifier.fillMaxWidth().statusBarsPadding().padding(12.dp)) {
            Row(Modifier.fillMaxWidth()) {
                list.forEachIndexed { j, _ ->
                    Box(
                        Modifier.weight(1f).height(3.dp).padding(horizontal = 2.dp)
                            .background(if (j <= i) Color.White else Color.White.copy(alpha = 0.3f)),
                    )
                }
            }
            Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Cover(s.avatar, Modifier.size(34.dp).clip(CircleShape))
                Spacer(Modifier.width(8.dp))
                Text(s.user, color = Color.White, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                if (s.mine) IconButton({ vm.deleteStory(s.id) }) { Icon(Icons.Default.Delete, "Delete", tint = Color.White) }
                IconButton(onClose) { Icon(Icons.Default.Close, "Close", tint = Color.White) }
            }
        }
        if (s.text.isNotBlank()) {
            Text(
                s.text, color = Color.White, textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(24.dp)
                    .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(10.dp)).padding(12.dp),
            )
        }
    }
}

// ======================= Profiles =======================

@Composable
fun PersonRow(u: User, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Cover(u.avatar, Modifier.size(48.dp).clip(CircleShape))
        Spacer(Modifier.width(12.dp))
        Column {
            Text(u.name, fontWeight = FontWeight.Medium)
            Text("@${u.un}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun ProfileScreen(vm: MainVM, id: String, close: () -> Unit) {
    val u = vm.userById(id)
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(close) { Icon(Icons.Default.ArrowBack, "Back") }
                Text(u?.name ?: "User", style = MaterialTheme.typography.titleMedium)
            }
            if (u == null) Box(Modifier.fillMaxSize(), Alignment.Center) { Text("User not found") }
            else ProfileList(vm, u, u.id == vm.me?.id)
        }
    }
}

@Composable
fun ProfileList(vm: MainVM, u: User, isMe: Boolean) {
    val songs = vm.songs.filter { it.uid == u.id }
    val nfts by produceState(emptyList<Nft>(), u.id, vm.inventory.size) {
        value = runCatching { vm.publicNfts(u.id) }.getOrDefault(emptyList())
    }
    val shown = nfts.filter { !it.raw }
    val pinned = u.pins.mapNotNull { pid -> shown.firstOrNull { it.id.toString() == pid } }
    var openNft by remember { mutableStateOf<Nft?>(null) }
    var editing by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { it?.let(vm::upload) }

    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Cover(u.banner, Modifier.fillMaxWidth().height(140.dp))
            Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Cover(u.avatar, Modifier.size(96.dp).clip(CircleShape))
                Spacer(Modifier.height(10.dp))
                Text(u.name, style = MaterialTheme.typography.titleLarge)
                Text("@${u.un}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (u.bio.isNotBlank()) Text(u.bio, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp))
                Text(
                    "${u.followers} followers · ${u.following} following",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp),
                )
                Spacer(Modifier.height(12.dp))
                if (isMe) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton({ editing = true }) { Icon(Icons.Default.Edit, null); Spacer(Modifier.width(6.dp)); Text("Edit") }
                        Button({ picker.launch("audio/*") }, enabled = !vm.busy) {
                            Icon(Icons.Default.Upload, null); Spacer(Modifier.width(6.dp)); Text(if (vm.busy) "Wait…" else "Upload")
                        }
                    }
                    TextButton({ vm.logout() }) { Text("Log out") }
                } else {
                    if (u.fme) OutlinedButton({ vm.toggleFollow(u) }) { Text("Following") }
                    else Button({ vm.toggleFollow(u) }) { Icon(Icons.Default.PersonAdd, null); Spacer(Modifier.width(6.dp)); Text("Follow") }
                }
            }
        }
        if (pinned.isNotEmpty()) item { NftStrip("Pinned", pinned) { openNft = it } }
        if (shown.isNotEmpty()) item { NftStrip("NFTs (${shown.size})", shown) { openNft = it } }
        if (songs.isNotEmpty()) item {
            Text("Songs", Modifier.padding(horizontal = 16.dp, vertical = 8.dp), style = MaterialTheme.typography.titleMedium)
        }
        items(songs, key = { it.id }) { SongRow(vm, it, songs) }
    }
    openNft?.let { n ->
        val mode = if (isMe && vm.inventory.any { it.id == n.id }) "mine" else "view"
        NftDetailDialog(vm, n, mode) { openNft = null }
    }
    if (editing) EditProfileDialog(vm, u) { editing = false }
}

@Composable
private fun NftStrip(title: String, items: List<Nft>, onClick: (Nft) -> Unit) {
    Column(Modifier.padding(vertical = 8.dp)) {
        Text(title, Modifier.padding(horizontal = 16.dp, vertical = 4.dp), style = MaterialTheme.typography.titleMedium)
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(items, key = { it.id }) { NftCard(it, 120.dp) { onClick(it) } }
        }
    }
}

@Composable
fun EditProfileDialog(vm: MainVM, u: User, close: () -> Unit) {
    var display by remember { mutableStateOf(u.name) }
    var bio by remember { mutableStateOf(u.bio) }
    var avatar by remember { mutableStateOf<Uri?>(null) }
    var banner by remember { mutableStateOf<Uri?>(null) }
    val pickAvatar = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { if (it != null) avatar = it }
    val pickBanner = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { if (it != null) banner = it }
    AlertDialog(
        onDismissRequest = close,
        title = { Text("Edit profile") },
        text = {
            Column {
                OutlinedTextField(display, { display = it.take(30) }, Modifier.fillMaxWidth(), label = { Text("Display name") }, singleLine = true)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(bio, { bio = it.take(160) }, Modifier.fillMaxWidth(), label = { Text("Bio") }, maxLines = 4)
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton({ pickAvatar.launch("image/*") }) { Text(if (avatar != null) "Photo ✓" else "Photo") }
                    OutlinedButton({ pickBanner.launch("image/*") }) { Text(if (banner != null) "Banner ✓" else "Banner") }
                }
            }
        },
        confirmButton = { TextButton({ vm.saveProfile(display.trim(), bio.trim(), avatar, banner); close() }) { Text("Save") } },
        dismissButton = { TextButton(close) { Text("Cancel") } },
    )
}
