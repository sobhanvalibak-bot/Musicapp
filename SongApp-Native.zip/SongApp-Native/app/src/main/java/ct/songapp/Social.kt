@file:OptIn(ExperimentalMaterial3Api::class)

package ct.songapp

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlin.math.roundToInt

val LocalOpenUpload = compositionLocalOf<() -> Unit> { {} }

// ============================ Stories ============================

@Composable
fun StoriesRow(vm: MainVM, open: (String) -> Unit, onPick: (Uri) -> Unit) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { it?.let(onPick) }
    val groups = vm.stories.groupBy { it.uid }.entries.sortedByDescending { e -> e.value.maxOf { it.t } }
    val mineGroup = groups.firstOrNull { it.value.first().mine }
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Bubble(
                if (mineGroup != null) "Add story" else "Your story", vm.me?.avatar.orEmpty(), ring = false, plus = true,
            ) { picker.launch("image/*") }
        }
        items(groups, key = { it.key }) { e ->
            val s = e.value.first()
            Bubble(if (s.mine) "You" else s.user, s.avatar, ring = true, plus = false) { open(e.key) }
        }
    }
}

@Composable
private fun Bubble(label: String, avatar: String, ring: Boolean, plus: Boolean, onClick: () -> Unit) {
    Column(Modifier.width(68.dp).clickable(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        Box {
            RingAvatar(avatar, 66.dp, ring)
            if (plus) Box(
                Modifier.align(Alignment.BottomEnd).size(22.dp).clip(CircleShape).background(P.grad2),
                Alignment.Center,
            ) { Icon(Icons.Default.Add, null, Modifier.size(16.dp), tint = Color.White) }
        }
        Text(label, fontSize = 12.sp, color = P.mute, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
    }
}

@Composable
fun StoryViewer(vm: MainVM, uid: String, onClose: () -> Unit) {
    val list = vm.stories.filter { it.uid == uid }.sortedBy { it.t }
    if (list.isEmpty()) { LaunchedEffect(Unit) { onClose() }; return }
    var idx by remember { mutableIntStateOf(0) }
    var held by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var dy by remember { mutableFloatStateOf(0f) }
    val i = idx.coerceIn(0, list.lastIndex)
    val s = list[i]
    val prog = remember(i) { Animatable(0f) }
    val paused = held || confirmDelete

    LaunchedEffect(i, paused) {
        if (!paused) {
            prog.animateTo(1f, tween(((1f - prog.value) * 5000).toInt().coerceAtLeast(1), easing = LinearEasing))
            if (i < list.lastIndex) idx = i + 1 else onClose()
        }
    }

    Box(
        Modifier.fillMaxSize().background(Color.Black)
            .offset { IntOffset(0, dy.roundToInt()) }
            .graphicsLayer { alpha = 1f - (dy / 900f).coerceIn(0f, 0.6f) }
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = { held = true },
                    onDragEnd = { held = false; if (dy > 240f) onClose() else dy = 0f },
                    onDragCancel = { held = false; dy = 0f },
                ) { _, d -> dy = (dy + d).coerceAtLeast(0f) }
            }
            .pointerInput(i) {
                detectTapGestures(
                    onPress = { held = true; tryAwaitRelease(); held = false },
                    onTap = { o ->
                        if (o.x < size.width / 3) { if (i > 0) idx = i - 1 else idx = 0 }
                        else if (i < list.lastIndex) idx = i + 1 else onClose()
                    },
                )
            },
    ) {
        if (s.url.isNotEmpty()) AsyncImage(s.url, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        // سایه‌ی بالا و پایین
        Box(Modifier.fillMaxWidth().height(160.dp).background(Brush.verticalGradient(listOf(Color(0xAA000000), Color.Transparent))))
        Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(220.dp).background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000)))))

        Column(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 12.dp, vertical = 10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                list.forEachIndexed { j, _ ->
                    val f = when { j < i -> 1f; j == i -> prog.value; else -> 0f }
                    Box(Modifier.weight(1f).height(3.dp).clip(CircleShape).background(Color(0x4DFFFFFF))) {
                        Box(Modifier.fillMaxHeight().fillMaxWidth(f).background(Color.White))
                    }
                }
            }
            Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                RingAvatar(s.avatar, 40.dp, ring = true)
                Spacer(Modifier.width(8.dp))
                Text(s.user, color = Color.White, fontWeight = FontWeight.SemiBold)
                Text("  ${ago(s.t)}", color = Color(0xB3FFFFFF), fontSize = 13.sp, modifier = Modifier.weight(1f))
                if (s.mine) IconButton({ confirmDelete = true }) { Icon(Icons.Default.Delete, "Delete", tint = Color.White) }
                IconButton(onClose) { Icon(Icons.Default.Close, "Close", tint = Color.White) }
            }
        }
        if (s.text.isNotBlank()) Text(
            s.text, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center,
            modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(horizontal = 28.dp, vertical = 40.dp),
        )
    }
    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        containerColor = P.card,
        title = { Text("Delete story?") },
        confirmButton = { TextButton({ confirmDelete = false; vm.deleteStory(s.id) }) { Text("Delete", color = P.pink) } },
        dismissButton = { TextButton({ confirmDelete = false }) { Text("Cancel", color = P.mute) } },
    )
}

@Composable
fun StoryComposer(vm: MainVM, uri: Uri, close: () -> Unit) {
    var text by remember { mutableStateOf("") }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AsyncImage(uri, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        Box(Modifier.fillMaxWidth().height(140.dp).background(Brush.verticalGradient(listOf(Color(0xAA000000), Color.Transparent))))
        Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(260.dp).background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xDD000000)))))
        IconButton(close, Modifier.statusBarsPadding().padding(8.dp)) { Icon(Icons.Default.Close, "Close", tint = Color.White) }
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().imePadding().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            OutlinedTextField(
                text, { text = it.take(80) }, Modifier.fillMaxWidth(),
                placeholder = { Text("Add a caption…", color = P.mute) },
                shape = RoundedCornerShape(18.dp), colors = glassFieldColors(), maxLines = 3,
            )
            GradButton(
                "Share to story", { vm.addStory(uri, text.trim()); close() },
                Modifier.fillMaxWidth(), enabled = !vm.busy, loading = vm.busy, icon = Icons.Default.Send,
            )
        }
    }
}

// ============================ Profiles ============================

@Composable
fun PersonRow(u: User, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp).clip(RoundedCornerShape(14.dp))
            .clickable { onClick() }.padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Cover(u.avatar, Modifier.size(48.dp).clip(CircleShape), 100.dp)
        Spacer(Modifier.width(14.dp))
        Column {
            Text(u.name, fontWeight = FontWeight.Medium)
            Text("@${u.un}", fontSize = 13.sp, color = P.mute)
        }
    }
}

@Composable
fun ProfileScreen(vm: MainVM, id: String, bottom: Dp, close: () -> Unit) {
    val u = vm.userById(id)
    AppBackground {
        if (u == null) Box(Modifier.fillMaxSize(), Alignment.Center) { Text("User not found", color = P.mute) }
        else ProfileList(vm, u, u.id == vm.me?.id, bottom, close)
    }
}

@Composable
private fun Segmented(items: List<String>, sel: Int, onSel: (Int) -> Unit) {
    Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp).fillMaxWidth().glass(24.dp).padding(4.dp)) {
        items.forEachIndexed { i, t ->
            Box(
                Modifier.weight(1f).height(38.dp).clip(CircleShape)
                    .then(if (i == sel) Modifier.background(P.grad2) else Modifier)
                    .clickable { onSel(i) },
                Alignment.Center,
            ) { Text(t, color = if (i == sel) Color.White else P.mute, fontWeight = FontWeight.Medium, fontSize = 14.sp) }
        }
    }
}

@Composable
private fun Stat(n: Int, label: String, modifier: Modifier) {
    Column(modifier.glass(16.dp).padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("$n", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(label, fontSize = 12.sp, color = P.mute)
    }
}

@Composable
fun ProfileList(vm: MainVM, u: User, isMe: Boolean, bottom: Dp, onBack: (() -> Unit)? = null) {
    val songs = vm.songs.filter { it.uid == u.id }
    val nfts by produceState(emptyList<Nft>(), u.id, vm.inventory.size) {
        value = runCatching { vm.publicNfts(u.id) }.getOrDefault(emptyList())
    }
    val shown = nfts.filter { !it.raw }
    val pinned = u.pins.mapNotNull { pid -> shown.firstOrNull { it.id.toString() == pid } }
    var openNft by remember { mutableStateOf<Nft?>(null) }
    var editing by remember { mutableStateOf(false) }
    var seg by remember { mutableIntStateOf(0) }
    val openUpload = LocalOpenUpload.current

    if (isMe && seg == 1) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Segmented(listOf("Songs", "NFT"), seg) { seg = it }
            Box(Modifier.weight(1f).padding(bottom = bottom)) { NftTab(vm) }
        }
    } else {
        Box(Modifier.fillMaxSize()) {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = bottom)) {
                item {
                    Box(Modifier.fillMaxWidth().height(238.dp)) {
                        Box(Modifier.fillMaxWidth().height(190.dp)) {
                            if (u.banner.isNotEmpty()) AsyncImage(u.banner, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                            else Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF3B1A7A), Color(0xFF8B1AA8)))))
                            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x66000000), Color.Transparent, P.bg))))
                        }
                        RingAvatar(u.avatar, 104.dp, true, Modifier.align(Alignment.BottomCenter))
                    }
                    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(u.name, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Text("@${u.un}", color = P.mute)
                        if (u.bio.isNotBlank()) Text(u.bio, textAlign = TextAlign.Center, color = P.ink.copy(alpha = 0.85f), modifier = Modifier.padding(top = 8.dp))
                        Spacer(Modifier.height(14.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Stat(songs.size, "Songs", Modifier.weight(1f))
                            Stat(u.followers, "Followers", Modifier.weight(1f))
                            Stat(u.following, "Following", Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(14.dp))
                        if (isMe) {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                GhostButton("Edit", { editing = true }, icon = Icons.Default.Edit)
                                GradButton("Upload", openUpload, icon = Icons.Default.Upload)
                                IconButton({ vm.logout() }) { Icon(Icons.Default.Logout, "Log out", tint = P.mute) }
                            }
                        } else if (u.fme) GhostButton("Following", { vm.toggleFollow(u) })
                        else GradButton("Follow", { vm.toggleFollow(u) }, icon = Icons.Default.PersonAdd)
                    }
                    if (isMe) { Spacer(Modifier.height(8.dp)); Segmented(listOf("Songs", "NFT"), seg) { seg = it } }
                }
                if (pinned.isNotEmpty()) item { NftStrip("Pinned", pinned) { openNft = it } }
                if (shown.isNotEmpty()) item { NftStrip("NFTs (${shown.size})", shown) { openNft = it } }
                item { SectionTitle("Songs (${songs.size})") }
                if (songs.isEmpty()) item { Empty("No songs yet") }
                items(songs, key = { it.id }) { SongRow(vm, it, songs) }
            }
            if (onBack != null) IconButton(
                onBack, Modifier.statusBarsPadding().padding(8.dp).clip(CircleShape).background(Color(0x66000000)),
            ) { Icon(Icons.Default.ArrowBack, "Back", tint = Color.White) }
        }
    }
    openNft?.let { n ->
        val mode = if (isMe && vm.inventory.any { it.id == n.id }) "mine" else "view"
        NftDetailDialog(vm, n, mode) { openNft = null }
    }
    if (editing) EditProfileSheet(vm, u) { editing = false }
}

@Composable
private fun NftStrip(title: String, items: List<Nft>, onClick: (Nft) -> Unit) {
    Column(Modifier.padding(vertical = 6.dp)) {
        SectionTitle(title)
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(items, key = { it.id }) { NftCard(it, 120.dp) { onClick(it) } }
        }
    }
}

@Composable
fun EditProfileSheet(vm: MainVM, u: User, close: () -> Unit) {
    var display by remember { mutableStateOf(u.name) }
    var bio by remember { mutableStateOf(u.bio) }
    var avatar by remember { mutableStateOf<Uri?>(null) }
    var banner by remember { mutableStateOf<Uri?>(null) }
    val pickAvatar = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { if (it != null) avatar = it }
    val pickBanner = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { if (it != null) banner = it }
    ModalBottomSheet(close, containerColor = P.card, contentColor = P.ink) {
        Column(Modifier.padding(horizontal = 20.dp).navigationBarsPadding().imePadding()) {
            Text("Edit profile", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(14.dp))
            Box(Modifier.fillMaxWidth().height(170.dp)) {
                Box(Modifier.fillMaxWidth().height(120.dp).clip(RoundedCornerShape(16.dp)).background(P.card2).clickable { pickBanner.launch("image/*") }, Alignment.Center) {
                    if (banner != null) AsyncImage(banner, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    else if (u.banner.isNotEmpty()) AsyncImage(u.banner, null, Modifier.fillMaxSize().alpha(0.7f), contentScale = ContentScale.Crop)
                    Icon(Icons.Default.PhotoCamera, null, tint = Color.White)
                }
                Box(Modifier.align(Alignment.BottomStart).padding(start = 16.dp).size(84.dp).clip(CircleShape).background(P.card2).clickable { pickAvatar.launch("image/*") }, Alignment.Center) {
                    if (avatar != null) AsyncImage(avatar, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    else if (u.avatar.isNotEmpty()) AsyncImage(u.avatar, null, Modifier.fillMaxSize().alpha(0.7f), contentScale = ContentScale.Crop)
                    Icon(Icons.Default.PhotoCamera, null, tint = Color.White)
                }
            }
            OutlinedTextField(display, { display = it.take(30) }, Modifier.fillMaxWidth(), label = { Text("Display name") }, singleLine = true, shape = RoundedCornerShape(16.dp), colors = glassFieldColors())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(bio, { bio = it.take(160) }, Modifier.fillMaxWidth(), label = { Text("Bio") }, maxLines = 4, shape = RoundedCornerShape(16.dp), colors = glassFieldColors())
            Spacer(Modifier.height(16.dp))
            GradButton("Save", { vm.saveProfile(display.trim(), bio.trim(), avatar, banner); close() }, Modifier.fillMaxWidth())
            Spacer(Modifier.height(20.dp))
        }
    }
}
