@file:OptIn(ExperimentalMaterial3Api::class)

package ct.songapp

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.airbnb.lottie.compose.*
import org.json.JSONObject

@Composable
fun LottieFromPath(path: String, modifier: Modifier) {
    val json by produceState<String?>(null, path) { value = if (path.isEmpty()) null else Assets.json(path) }
    val j = json
    if (j != null) {
        val comp by rememberLottieComposition(LottieCompositionSpec.JsonString(j))
        LottieAnimation(composition = comp, modifier = modifier, iterations = LottieConstants.IterateForever)
    }
}

private fun parseColor(s: String, fallback: Color): Color =
    try { Color(android.graphics.Color.parseColor(s)) } catch (e: Exception) { fallback }

/** پس‌زمینه‌ی گرادیانی (از JSON بک‌دراپ) + انیمیشن Lottie مدل */
@Composable
fun NftArt(n: Nft, modifier: Modifier) {
    val def = Color(0xFFB186BB) to Color(0xFF875A91)
    val colors by produceState(def, n.backdrop) {
        if (n.backdrop.isNotEmpty()) {
            val s = Assets.json(n.backdrop)
            if (s != null) runCatching {
                val j = JSONObject(s)
                value = parseColor(j.optString("center_color"), def.first) to parseColor(j.optString("edge_color"), def.second)
            }
        }
    }
    Box(
        modifier.clip(RoundedCornerShape(14.dp))
            .background(Brush.radialGradient(listOf(colors.first, colors.second))),
        Alignment.Center,
    ) {
        LottieFromPath(if (n.raw) n.rawPath else n.model, Modifier.fillMaxSize(0.82f))
    }
}

@Composable
fun NftCard(n: Nft, width: Dp, onClick: () -> Unit) {
    Column(Modifier.width(width).clickable { onClick() }) {
        NftArt(n, Modifier.size(width))
        Text(
            if (n.raw) "${n.collection} (raw)" else "${n.collection} #${n.num}",
            style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 4.dp),
        )
        if (n.price > 0) Text("${n.price} coins", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
fun NftTab(vm: MainVM) {
    var sub by remember { mutableIntStateOf(0) }
    var sel by remember { mutableStateOf<Nft?>(null) }
    var selMode by remember { mutableStateOf("mine") }
    LaunchedEffect(Unit) { vm.loadNft() }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Balance", Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant)
            Icon(Icons.Default.MonetizationOn, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(6.dp))
            Text("${vm.coins}", fontWeight = FontWeight.Bold)
        }
        TabRow(selectedTabIndex = sub) {
            listOf("Gifts", "Mine", "Market").forEachIndexed { i, t -> Tab(sub == i, { sub = i }, text = { Text(t) }) }
        }
        if (vm.nftLoading) LinearProgressIndicator(Modifier.fillMaxWidth())
        LazyVerticalGrid(
            GridCells.Fixed(2), Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            when (sub) {
                0 -> {
                    if (vm.collections.isEmpty()) item(span = { GridItemSpan(maxLineSpan) }) { EmptyHint() }
                    items(vm.collections, key = { it.id }) { CollectionCard(vm, it) }
                }
                1 -> {
                    if (vm.inventory.isEmpty()) item(span = { GridItemSpan(maxLineSpan) }) { EmptyHint() }
                    items(vm.inventory, key = { it.id }) { n ->
                        BoxWithConstraints { NftCard(n, maxWidth) { sel = n; selMode = "mine" } }
                    }
                }
                else -> {
                    if (vm.market.isEmpty()) item(span = { GridItemSpan(maxLineSpan) }) { EmptyHint() }
                    items(vm.market, key = { it.id }) { n ->
                        BoxWithConstraints {
                            NftCard(n, maxWidth) { sel = n; selMode = if (n.owner == vm.me?.id) "mine" else "market" }
                        }
                    }
                }
            }
        }
    }
    sel?.let { NftDetailDialog(vm, it, selMode) { sel = null } }
}

@Composable
private fun EmptyHint() {
    Box(Modifier.fillMaxWidth().padding(32.dp), Alignment.Center) {
        Text("چیزی برای نمایش نیست", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun CollectionCard(vm: MainVM, c: NftCollection) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(12.dp)) {
            Box(
                Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surface),
                Alignment.Center,
            ) { LottieFromPath(c.rawPath, Modifier.fillMaxSize(0.85f)) }
            Text(c.name, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp))
            Text(
                "${c.minted}/${c.limit} · ${c.price} coins", style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
            if (!c.upgradeEnabled) {
                Button({ vm.buyRaw(c) }, Modifier.fillMaxWidth(), enabled = !vm.busy && c.minted < c.limit) { Text("Buy") }
            } else {
                Text("Upgrades live", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
fun NftDetailDialog(vm: MainVM, n: Nft, mode: String, close: () -> Unit) {
    var price by remember { mutableStateOf(if (n.price > 0) n.price.toString() else "") }
    var picking by remember { mutableStateOf(false) }
    val id = n.id.toString()
    val pinned = id in (vm.me?.pins ?: emptyList())
    val equipped = vm.me?.eq == id

    AlertDialog(
        onDismissRequest = close,
        confirmButton = { TextButton(close) { Text("Close") } },
        title = { Text(if (n.raw) "${n.collection} (raw)" else "${n.collection} #${n.num}") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                NftArt(n, Modifier.fillMaxWidth().aspectRatio(1f))
                Spacer(Modifier.height(12.dp))
                if (!n.raw) {
                    Trait("Model", n.modelName, n.modelPm)
                    Trait("Symbol", n.symbolName, n.symbolPm)
                    Trait("Backdrop", n.backdropName, n.backdropPm)
                }
                if (n.price > 0) Text("Listed for ${n.price} coins", color = MaterialTheme.colorScheme.primary)
                when (mode) {
                    "market" -> {
                        Text("Seller: ${n.ownerName}", Modifier.padding(top = 4.dp))
                        Button({ vm.buyListing(n); close() }, Modifier.fillMaxWidth().padding(top = 8.dp), enabled = !vm.busy) {
                            Text("Buy for ${n.price} coins")
                        }
                    }
                    "mine" -> if (n.raw) {
                        if (n.upgradeEnabled) {
                            Button({ vm.upgrade(n); close() }, Modifier.fillMaxWidth().padding(top = 8.dp), enabled = !vm.busy) { Text("Upgrade") }
                        } else Text("Upgrade is not available yet", Modifier.padding(top = 8.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                price, { price = it.filter { c -> c.isDigit() }.take(10) }, Modifier.weight(1f),
                                label = { Text("Price (coins)") }, singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            )
                            Spacer(Modifier.width(8.dp))
                            Button({ vm.listNft(n, price.toIntOrNull() ?: 0); close() }, enabled = !vm.busy && price.isNotEmpty()) {
                                Text(if (n.price > 0) "Update" else "Sell")
                            }
                        }
                        if (n.price > 0) TextButton({ vm.listNft(n, 0); close() }) { Text("Remove listing") }
                        TextButton({ picking = true }) { Text("Transfer to user…") }
                        TextButton({ vm.togglePin(n) }) { Text(if (pinned) "Unpin from profile" else "Pin to profile") }
                        TextButton({ vm.toggleEquip(n) }) { Text(if (equipped) "Remove badge" else "Use as profile badge") }
                    }
                }
            }
        },
    )
    if (picking) UserPickerDialog(vm, { picking = false }) { uid -> picking = false; vm.transfer(n, uid); close() }
}

@Composable
private fun Trait(label: String, name: String, pm: Int) {
    if (name.isBlank()) return
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text(label, Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text("$name · ${"%.1f".format(pm / 10.0)}%")
    }
}

@Composable
fun UserPickerDialog(vm: MainVM, dismiss: () -> Unit, pick: (String) -> Unit) {
    AlertDialog(
        onDismissRequest = dismiss,
        confirmButton = { TextButton(dismiss) { Text("Cancel") } },
        title = { Text("Choose recipient") },
        text = {
            LazyColumn(Modifier.heightIn(max = 360.dp)) {
                items(vm.users, key = { it.id }) { u ->
                    Row(Modifier.fillMaxWidth().clickable { pick(u.id) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Cover(u.avatar, Modifier.size(36.dp).clip(CircleShape))
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(u.name)
                            Text("@${u.un}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        },
    )
}
