package ct.songapp

import android.content.Context
import android.content.SharedPreferences
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

val BASE: String = BuildConfig.SERVER_URL

private const val UA =
    "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

class ApiException(message: String, val code: Int = 0) : Exception(message)

/** CookieJar ساده؛ کوکی __test (چالش هاست‌های رایگان) را هم نگه می‌دارد. */
class Jar(private val prefs: SharedPreferences) : CookieJar {
    private val store = mutableListOf<Cookie>()

    init {
        prefs.getString("__test", null)?.let { setTest(BASE.toHttpUrl().host, it, false) }
    }

    @Synchronized
    fun setTest(host: String, v: String, persist: Boolean = true) {
        store.removeAll { it.name == "__test" }
        store.add(
            Cookie.Builder().name("__test").value(v).hostOnlyDomain(host)
                .path("/").expiresAt(2145830400000L).build()
        )
        if (persist) prefs.edit().putString("__test", v).apply()
    }

    @Synchronized
    override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
        for (c in cookies) {
            store.removeAll { it.name == c.name && it.domain == c.domain && it.path == c.path }
            store.add(c)
        }
    }

    @Synchronized
    override fun loadForRequest(url: HttpUrl): List<Cookie> {
        val now = System.currentTimeMillis()
        store.removeAll { it.expiresAt < now }
        return store.filter { it.matches(url) }
    }
}

/**
 * هاست‌های رایگان (InfinityFree / ct.ws) برای کلاینت‌های غیرمرورگر یک صفحه‌ی
 * چالش AES برمی‌گردانند. اینجا همان چالش حل می‌شود و درخواست تکرار می‌شود.
 */
class Challenge(private val jar: Jar) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val req = chain.request()
        val resp = chain.proceed(req)
        if (resp.header("Content-Type")?.contains("text/html", true) != true) return resp
        val head = resp.peekBody(16384).string()
        if (!head.contains("slowAES")) return resp
        val nums = Regex("toNumbers\\(\"([0-9a-fA-F]+)\"\\)").findAll(head).map { it.groupValues[1] }.toList()
        if (nums.size < 3) return resp
        val v = solve(nums[0], nums[1], nums[2]) ?: return resp
        jar.setTest(req.url.host, v)
        resp.close()
        val url = req.url.newBuilder().setQueryParameter("i", "1").build()
        return chain.proceed(req.newBuilder().url(url).build())
    }

    private fun hex(s: String) = ByteArray(s.length / 2) { s.substring(2 * it, 2 * it + 2).toInt(16).toByte() }

    private fun solve(a: String, b: String, c: String): String? = try {
        val ci = Cipher.getInstance("AES/CBC/NoPadding")
        ci.init(Cipher.DECRYPT_MODE, SecretKeySpec(hex(a), "AES"), IvParameterSpec(hex(b)))
        ci.doFinal(hex(c)).joinToString("") { "%02x".format(it) }
    } catch (e: Exception) {
        null
    }
}

object Net {
    lateinit var client: OkHttpClient
    @Volatile var token: String? = null

    fun init(ctx: Context) {
        val jar = Jar(ctx.getSharedPreferences("net", 0))
        client = OkHttpClient.Builder()
            .cookieJar(jar)
            .addInterceptor { ch -> ch.proceed(ch.request().newBuilder().header("User-Agent", UA).build()) }
            .addInterceptor(Challenge(jar))
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(180, TimeUnit.SECONDS)
            .build()
    }
}

object Api {
    private val JSON = "application/json; charset=utf-8".toMediaType()

    /** درخواست به api.php?route=/xxx ؛ خروجی JSONObject یا JSONArray */
    suspend fun call(method: String, route: String, json: JSONObject? = null, body: RequestBody? = null): Any =
        withContext(Dispatchers.IO) {
            val url = BASE.toHttpUrl().newBuilder()
                .addPathSegment("api.php").addQueryParameter("route", route).build()
            val rb: RequestBody? = when {
                body != null -> body
                json != null -> json.toString().toRequestBody(JSON)
                method == "GET" || method == "DELETE" -> null
                else -> "{}".toRequestBody(JSON)
            }
            val req = Request.Builder().url(url).method(method, rb).apply {
                Net.token?.let { header("Authorization", "Bearer $it") }
            }.build()
            Net.client.newCall(req).execute().use { r ->
                val s = r.body?.string().orEmpty()
                val parsed: Any = try {
                    if (s.trimStart().startsWith("[")) JSONArray(s) else JSONObject(s)
                } catch (e: Exception) {
                    throw ApiException("Bad server response (${r.code})", r.code)
                }
                if (parsed is JSONObject && parsed.has("e")) throw ApiException(parsed.optString("e"), r.code)
                if (!r.isSuccessful) throw ApiException("HTTP ${r.code}", r.code)
                parsed
            }
        }

    suspend fun obj(method: String, route: String, json: JSONObject? = null): JSONObject =
        call(method, route, json) as JSONObject

    data class AudioMeta(val title: String, val artist: String, val album: String, val name: String)

    /** خواندن تگ‌های فایل صوتی برای پر کردن خودکار فرم آپلود */
    suspend fun probe(ctx: Context, uri: Uri): AudioMeta = withContext(Dispatchers.IO) {
        var name = "song.mp3"
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) name = it.getString(0) ?: name
        }
        var t = ""; var a = ""; var al = ""
        val mmr = MediaMetadataRetriever()
        try {
            mmr.setDataSource(ctx, uri)
            t = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE).orEmpty()
            a = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST).orEmpty()
            al = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM).orEmpty()
        } catch (_: Exception) {
        } finally { mmr.release() }
        if (t.isBlank()) t = name.substringBeforeLast('.')
        AudioMeta(t, a, al, name)
    }

    suspend fun uploadSong(
        ctx: Context, uri: Uri,
        ovTitle: String? = null, ovArtist: String? = null, ovAlbum: String? = null, cover: Uri? = null,
    ): JSONObject = withContext(Dispatchers.IO) {
        val cr = ctx.contentResolver
        var display = "song.mp3"
        cr.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) display = it.getString(0) ?: display
        }
        val tmp = File(ctx.cacheDir, "up_${System.currentTimeMillis()}")
        cr.openInputStream(uri)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
        var title = ""; var artist = ""; var album = ""; var dur = 0.0
        val mmr = MediaMetadataRetriever()
        try {
            mmr.setDataSource(tmp.absolutePath)
            title = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE).orEmpty()
            artist = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST).orEmpty()
            album = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM).orEmpty()
            dur = (mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toDoubleOrNull() ?: 0.0) / 1000.0
        } catch (_: Exception) {
        } finally {
            mmr.release()
        }
        if (title.isBlank()) title = display.substringBeforeLast('.')
        ovTitle?.takeIf { it.isNotBlank() }?.let { title = it }
        ovArtist?.let { artist = it }
        ovAlbum?.let { album = it }
        var coverTmp: File? = null
        if (cover != null) {
            coverTmp = File(ctx.cacheDir, "cv_${System.currentTimeMillis()}")
            cr.openInputStream(cover)?.use { i -> coverTmp.outputStream().use { o -> i.copyTo(o) } }
        }
        val mime = cr.getType(uri) ?: "audio/mpeg"
        val mp = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("title", title)
            .addFormDataPart("artist", artist)
            .addFormDataPart("album", album)
            .addFormDataPart("dur", dur.toString())
            .addFormDataPart("file", display, tmp.asRequestBody(mime.toMediaType()))
            .apply {
                coverTmp?.let {
                    addFormDataPart("cover", "cover.jpg", it.asRequestBody((cr.getType(cover!!) ?: "image/jpeg").toMediaType()))
                }
            }
            .build()
        try {
            call("POST", "/songs", body = mp) as JSONObject
        } finally {
            tmp.delete(); coverTmp?.delete()
        }
    }

    /** بدنه‌ی خام (برای فایل‌های Lottie) */
    suspend fun text(route: String): String = withContext(Dispatchers.IO) {
        val url = BASE.toHttpUrl().newBuilder()
            .addPathSegment("api.php").addQueryParameter("route", route).build()
        Net.client.newCall(Request.Builder().url(url).build()).execute().use { r ->
            if (!r.isSuccessful) throw ApiException("HTTP ${r.code}", r.code)
            r.body?.string().orEmpty()
        }
    }

    /** ارسال فرم multipart با فیلدهای متنی و فایل‌هایی که از Uri خوانده می‌شوند */
    suspend fun form(ctx: Context, route: String, fields: Map<String, String>, files: Map<String, Uri>): JSONObject =
        withContext(Dispatchers.IO) {
            val tmps = mutableListOf<File>()
            try {
                val b = MultipartBody.Builder().setType(MultipartBody.FORM)
                fields.forEach { (k, v) -> b.addFormDataPart(k, v) }
                for ((k, uri) in files) {
                    val cr = ctx.contentResolver
                    var name = "file"
                    cr.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                        if (it.moveToFirst()) name = it.getString(0) ?: name
                    }
                    val f = File(ctx.cacheDir, "f_${System.nanoTime()}")
                    cr.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                    tmps.add(f)
                    b.addFormDataPart(k, name, f.asRequestBody((cr.getType(uri) ?: "application/octet-stream").toMediaType()))
                }
                call("POST", route, body = b.build()) as JSONObject
            } finally {
                tmps.forEach { it.delete() }
            }
        }
}

/** کش فایل‌های JSON مربوط به NFT (Lottie و رنگ پس‌زمینه) */
object Assets {
    private val cache = object : android.util.LruCache<String, String>(32_000_000) {
        override fun sizeOf(key: String, value: String) = value.length
    }

    suspend fun json(path: String): String? {
        cache.get(path)?.let { return it }
        return try {
            Api.text("/nft/asset/$path").also { cache.put(path, it) }
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        }
    }
}
