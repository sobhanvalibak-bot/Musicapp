package ct.songapp

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

/** توکن‌های طراحی — همان رنگ‌های index.php (بنفش/سرخابی، شیشه‌ای) */
object P {
    val bg = Color(0xFF0A0716)
    val ink = Color(0xFFF3EEFF)
    val mute = Color(0xFF9D92C4)
    val p = Color(0xFF8B5CF6)
    val p2 = Color(0xFFD946EF)
    val pink = Color(0xFFF472B6)
    val sky = Color(0xFF38BDF8)
    val soft = Color(0xFFC4B5FD)
    val card = Color(0xFF130F24)
    val card2 = Color(0xFF1C1838)
    val line = Color(0x668B5CF6)
    val glass = Color(0x12FFFFFF)
    val ring: Brush get() = Brush.sweepGradient(listOf(pink, p, sky, pink))
    val grad: Brush get() = Brush.linearGradient(listOf(p, Color(0xFF6D28D9)))
    val grad2: Brush get() = Brush.linearGradient(listOf(p, p2))
}

fun Modifier.glass(r: Dp = 20.dp, fill: Color = P.glass): Modifier {
    val shape = RoundedCornerShape(r)
    return this.clip(shape).background(fill).border(1.dp, P.line, shape)
}

@Composable
fun MusicTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(
        primary = P.p, onPrimary = Color.White,
        secondary = P.p2, tertiary = P.pink,
        background = P.bg, onBackground = P.ink,
        surface = P.card, onSurface = P.ink,
        surfaceVariant = P.card2, onSurfaceVariant = P.mute,
        outline = P.line, outlineVariant = P.line,
        surfaceContainer = P.card, surfaceContainerHigh = P.card2, surfaceContainerHighest = P.card2,
    ),
    content = content,
)

/** پس‌زمینه‌ی رادیال بنفش + رنگ داینامیک اختیاری (از کاور آهنگ) */
@Composable
fun AppBackground(modifier: Modifier = Modifier, tint: Color? = null, content: @Composable BoxScope.() -> Unit) {
    Box(
        modifier.fillMaxSize().background(P.bg).drawBehind {
            drawRect(Brush.radialGradient(listOf(Color(0x553B1A7A), Color.Transparent), Offset(size.width * 0.8f, 0f), size.width * 0.9f))
            drawRect(Brush.radialGradient(listOf(Color(0x446D1B91), Color.Transparent), Offset(0f, size.height), size.width * 0.9f))
            tint?.let { drawRect(Brush.verticalGradient(listOf(it.copy(alpha = 0.5f), Color.Transparent), endY = size.height * 0.65f)) }
        },
        content = content,
    )
}

@Composable
fun Cover(url: String, modifier: Modifier, radius: Dp = 12.dp) {
    Box(modifier.clip(RoundedCornerShape(radius)).background(P.card2), Alignment.Center) {
        if (url.isNotEmpty()) AsyncImage(url, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else androidx.compose.material3.Icon(Icons.Default.MusicNote, null, tint = P.mute)
    }
}

@Composable
fun GradButton(
    text: String, onClick: () -> Unit, modifier: Modifier = Modifier,
    enabled: Boolean = true, loading: Boolean = false, icon: ImageVector? = null,
) {
    Box(
        modifier.height(48.dp).clip(CircleShape)
            .background(if (enabled) P.grad else SolidColor(Color(0x22FFFFFF)))
            .clickable(enabled = enabled && !loading, onClick = onClick),
        Alignment.Center,
    ) {
        if (loading) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
        else Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 22.dp)) {
            if (icon != null) { androidx.compose.material3.Icon(icon, null, Modifier.size(18.dp), tint = Color.White); Spacer(Modifier.width(8.dp)) }
            Text(text, color = Color.White, fontWeight = FontWeight.Medium, fontSize = 14.sp)
        }
    }
}

@Composable
fun GhostButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, icon: ImageVector? = null) {
    Box(
        modifier.height(44.dp).glass(22.dp, Color(0x14FFFFFF)).clickable(onClick = onClick),
        Alignment.Center,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 18.dp)) {
            if (icon != null) { androidx.compose.material3.Icon(icon, null, Modifier.size(18.dp), tint = P.ink); Spacer(Modifier.width(8.dp)) }
            Text(text, color = P.ink, fontSize = 14.sp)
        }
    }
}

/** حلقه‌ی گرادیانی استوری (conic-gradient وب) */
@Composable
fun RingAvatar(url: String, size: Dp, ring: Boolean, modifier: Modifier = Modifier) {
    Box(
        modifier.size(size).then(if (ring) Modifier.background(P.ring, CircleShape).padding(3.dp) else Modifier.padding(3.dp)),
        Alignment.Center,
    ) {
        Box(Modifier.fillMaxSize().clip(CircleShape).background(P.bg).padding(if (ring) 3.dp else 0.dp)) {
            Cover(url, Modifier.fillMaxSize().clip(CircleShape), radius = 100.dp)
        }
    }
}

@Composable
fun glassFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = P.p, unfocusedBorderColor = P.line,
    focusedContainerColor = Color(0x14FFFFFF), unfocusedContainerColor = Color(0x0DFFFFFF),
    cursorColor = P.p, focusedLabelColor = P.soft, unfocusedLabelColor = P.mute,
)

fun fmt(ms: Long): String { val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60) }

fun ago(t: Long): String {
    val m = ((System.currentTimeMillis() - t) / 60000).coerceAtLeast(0)
    return when {
        m < 1 -> "now"
        m < 60 -> "${m}m"
        m < 1440 -> "${m / 60}h"
        else -> "${m / 1440}d"
    }
}
