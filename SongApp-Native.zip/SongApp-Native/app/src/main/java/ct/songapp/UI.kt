@file:OptIn(ExperimentalMaterial3Api::class)

package ct.songapp

import android.content.Intent
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.palette.graphics.Palette
import coil.compose.AsyncImage
import coil.imageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.roundToInt
import kotlin.math.sin

val LocalOpenProfile = compositionLocalOf<(String) -> Unit> { {} }

// ============================ Root / Login ============================

@Composable
fun Root(vm: MainVM) {
    val ctx = LocalContext.current
    LaunchedEffect(vm.toast) {
        vm.toast?.let { Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show(); vm.toast = null }
    }
    AppBackground {
        when {
            vm.booting -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = P.p) }
            vm.token == null -> LoginScreen(vm)
            else -> MainScreen(vm)
        }
    }
}

@Composable
fun LoginScreen(vm: MainVM) {
    var u by remember { mutableStateOf("") }
    var p by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().systemBarsPadding().padding(28.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.size(104.dp).background(P.ring, CircleShape).padding(3.dp)) {
            Box(Modifier.fillMaxSize().clip(CircleShape).background(P.bg), Alignment.Center) {
                Icon(Icons.Default.MusicNote, null, Modifier.size(52.dp), tint = P.soft)
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("Music", style = TextStyle(brush = Brush.linearGradient(listOf(P.soft, P.p2)), fontSize = 44.sp, fontWeight = FontWeight.Bold))
        Text("BEYOND SOUNDS", color = P.mute, fontSize = 12.sp, letterSpacing = 4.sp, fontWeight = FontWeight.Light)
        Spacer(Modifier.height(32.dp))
        OutlinedTextField(
            u, { u = it.trim() }, Modifier.fillMaxWidth(), label = { Text("Username") }, singleLine = true,
            shape = RoundedCornerShape(16.dp), colors = glassFieldColors(),
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            p, { p = it }, Modifier.fillMaxWidth(), label = { Text("Password") }, singleLine = true,
            shape = RoundedCornerShape(16.dp), colors = glassFieldColors(),
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        )
        vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 10.dp)) }
        Spacer(Modifier.height(20.dp))
        val ok = !vm.busy && u.isNotEmpty() && p.isNotEmpty()
        GradButton("Log in", { vm.auth(false, u, p) }, Modifier.fillMaxWidth(), enabled = ok, loading = vm.busy)
        Spacer(Modifier.height(6.dp))
        TextButton({ vm.auth(true, u, p) }, enabled = ok) { Text("Create account", color = P.soft) }
    }
}

// ============================ Main shell ============================

@Composable
fun MainScreen(vm: MainVM) {
    var tab by remember { mutableIntStateOf(0) }
    var showPlayer by remember { mutableStateOf(false) }
    var showUpload by remember { mutableStateOf(false) }
    var profileId by remember { mutableStateOf<String?>(null) }
    var storyUid by remember { mutableStateOf<String?>(null) }
    var storyDraft by remember { mutableStateOf<Uri?>(null) }
    val p = vm.player
    LaunchedEffect(p.playing) { while (p.playing) { p.tick(); delay(500) } }
    val cur = vm.songs.firstOrNull { it.id == p.currentId }
    val navPad = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val bottom = 84.dp + navPad + (if (cur != null) 70.dp else 0.dp)
    val accent = if (cur != null && tab == 0 && profileId == null) rememberAccent(cur.cover) else null

    CompositionLocalProvider(
        LocalOpenProfile provides { profileId = it },
        LocalOpenUpload provides { showUpload = true },
    ) {
        Box(Modifier.fillMaxSize()) {
            // محتوای تب‌ها
            AppBackground(tint = accent?.copy(alpha = 0.35f)) {
                when (tab) {
                    0 -> HomeTab(vm, bottom, { storyUid = it }, { storyDraft = it })
                    1 -> SearchTab(vm, bottom)
                    2 -> LibraryTab(vm, bottom)
                    else -> vm.me?.let { ProfileList(vm, it, true, bottom) }
                }
            }
            profileId?.let { id ->
                BackHandler { profileId = null }
                ProfileScreen(vm, id, bottom) { profileId = null }
            }

            // پلیر کوچک + نوار پایین
            Column(Modifier.align(Alignment.BottomCenter)) {
                if (cur != null) MiniPlayer(vm, cur) { showPlayer = true }
                NavBar(tab, vm.me, { tab = it; profileId = null }, { showUpload = true })
            }

            if (showUpload) {
                BackHandler { showUpload = false }
                UploadScreen(vm) { showUpload = false }
            }
            if (showPlayer) BackHandler { showPlayer = false }
            AnimatedVisibility(
                showPlayer && cur != null,
                enter = slideInVertically { it }, exit = slideOutVertically { it },
            ) { NowPlaying(vm) { showPlayer = false } }

            storyDraft?.let { uri ->
                BackHandler { storyDraft = null }
                StoryComposer(vm, uri) { storyDraft = null }
            }
            storyUid?.let { uid ->
                BackHandler { storyUid = null }
                StoryViewer(vm, uid) { storyUid = null }
            }
        }
    }
}

@Composable
fun NavBar(tab: Int, me: User?, onTab: (Int) -> Unit, onAdd: () -> Unit) {
    Column(Modifier.fillMaxWidth().background(Color(0xF20C0820))) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(P.line.copy(alpha = 0.35f)))
        Row(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 6.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            NavItem(Icons.Default.Home, "Home", tab == 0, Modifier.weight(1f)) { onTab(0) }
            NavItem(Icons.Default.Search, "Explore", tab == 1, Modifier.weight(1f)) { onTab(1) }
            Box(Modifier.weight(1f), Alignment.Center) {
                Box(
                    Modifier.size(50.dp).shadow(14.dp, CircleShape, ambientColor = P.p, spotColor = P.p)
                        .clip(CircleShape).background(P.grad2).clickable(onClick = onAdd),
                    Alignment.Center,
                ) { Icon(Icons.Default.Add, "Upload", Modifier.size(28.dp), tint = Color.White) }
            }
            NavItem(Icons.Default.Favorite, "Library", tab == 2, Modifier.weight(1f)) { onTab(2) }
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).clickable { onTab(3) }.padding(vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                if (me != null && me.avatar.isNotBlank()) RingAvatar(me.avatar, 28.dp, tab == 3)
                else Icon(Icons.Default.Person, "Profile", Modifier.size(26.dp), tint = if (tab == 3) P.soft else P.mute)
                Text("Profile", fontSize = 11.sp, color = if (tab == 3) P.soft else P.mute)
            }
        }
    }
}

@Composable
private fun NavItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, on: Boolean, modifier: Modifier, click: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = click).padding(vertical = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, label, Modifier.size(24.dp), tint = if (on) P.soft else P.mute)
        Text(label, fontSize = 11.sp, color = if (on) P.soft else P.mute)
    }
}

// ============================ Home ============================

@Composable
fun SectionTitle(t: String) =
    Text(t, Modifier.padding(horizontal = 16.dp, vertical = 8.dp), fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = P.ink)

@Composable
fun HomeTab(vm: MainVM, bottom: androidx.compose.ui.unit.Dp, onStory: (String) -> Unit, onPick: (Uri) -> Unit) {
    val trending = remember(vm.songs) { vm.songs.sortedByDescending { it.plays }.take(10) }
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(bottom = bottom)) {
        item {
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 6.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Music", Modifier.weight(1f),
                    style = TextStyle(brush = Brush.linearGradient(listOf(P.soft, P.p2)), fontSize = 30.sp, fontWeight = FontWeight.Bold),
                )
                IconButton({ vm.refresh() }) { Icon(Icons.Default.Refresh, "Refresh", tint = P.mute) }
            }
            if (vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 16.dp), color = P.p, trackColor = Color.Transparent)
        }
        item { StoriesRow(vm, onStory, onPick) }
        if (trending.size >= 3) {
            item { SectionTitle("Trending") }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(trending, key = { "t" + it.id }) { TrackCard(vm, it, trending) }
                }
            }
        }
        item { SectionTitle("All songs") }
        if (vm.songs.isEmpty()) item { Empty("Nothing here yet") }
        items(vm.songs, key = { it.id }) { SongRow(vm, it, vm.songs) }
    }
}

@Composable
fun Empty(t: String) = Box(Modifier.fillMaxWidth().padding(48.dp), Alignment.Center) { Text(t, color = P.mute) }

@Composable
fun TrackCard(vm: MainVM, s: Song, list: List<Song>) {
    val active = vm.player.currentId == s.id
    Column(Modifier.width(140.dp).clip(RoundedCornerShape(16.dp)).clickable { vm.play(list, list.indexOf(s)) }) {
        Cover(s.cover, Modifier.size(140.dp), 16.dp)
        Text(
            s.title, Modifier.padding(top = 8.dp), maxLines = 1, overflow = TextOverflow.Ellipsis,
            fontWeight = FontWeight.Medium, fontSize = 14.sp, color = if (active) P.soft else P.ink,
        )
        Text(s.artist.ifBlank { s.user }, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, color = P.mute)
    }
}

@Composable
fun SongList(vm: MainVM, list: List<Song>, bottom: androidx.compose.ui.unit.Dp, header: (@Composable () -> Unit)? = null) {
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(bottom = bottom)) {
        header?.let { h -> item { h() } }
        if (list.isEmpty()) item { Empty("Nothing here yet") }
        items(list, key = { it.id }) { SongRow(vm, it, list) }
    }
}

@Composable
fun SongRow(vm: MainVM, s: Song, list: List<Song>) {
    val active = vm.player.currentId == s.id
    val openProfile = LocalOpenProfile.current
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp).clip(RoundedCornerShape(14.dp))
            .background(if (active) Color(0x248B5CF6) else Color.Transparent)
            .clickable { vm.play(list, list.indexOf(s)) }
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box {
            Cover(s.cover, Modifier.size(52.dp), 12.dp)
            if (active) Box(Modifier.size(52.dp).clip(RoundedCornerShape(12.dp)).background(Color(0x88000000)), Alignment.Center) {
                Icon(Icons.Default.GraphicEq, null, tint = P.soft)
            }
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium, fontSize = 15.sp,
                color = if (active) P.soft else P.ink,
            )
            Row {
                if (s.artist.isNotBlank()) Text(
                    s.artist, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    color = P.mute, modifier = Modifier.weight(1f, fill = false),
                )
                if (s.artist.isNotBlank() && s.user.isNotBlank()) Text(" • ", fontSize = 13.sp, color = P.mute)
                if (s.user.isNotBlank()) Text(
                    s.user, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    color = P.soft, modifier = Modifier.clickable { openProfile(s.uid) },
                )
            }
        }
        IconButton({ vm.toggleLike(s) }) {
            Icon(
                if (s.liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Like",
                tint = if (s.liked) P.pink else P.mute,
            )
        }
    }
}

// ============================ Search / Library ============================

@Composable
fun SearchTab(vm: MainVM, bottom: androidx.compose.ui.unit.Dp) {
    var q by remember { mutableStateOf("") }
    val open = LocalOpenProfile.current
    val key = q.trim()
    val songs = if (key.isEmpty()) emptyList() else vm.songs.filter {
        listOf(it.title, it.artist, it.album, it.user).any { f -> f.contains(key, ignoreCase = true) }
    }
    val people = if (key.isEmpty()) emptyList() else vm.users.filter {
        it.name.contains(key, ignoreCase = true) || it.un.contains(key, ignoreCase = true)
    }
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(bottom = bottom)) {
        item {
            Text("Explore", Modifier.padding(start = 16.dp, top = 12.dp), fontSize = 28.sp, fontWeight = FontWeight.Bold)
            OutlinedTextField(
                q, { q = it }, Modifier.fillMaxWidth().padding(16.dp), singleLine = true,
                placeholder = { Text("Songs, artists, people…", color = P.mute) },
                leadingIcon = { Icon(Icons.Default.Search, null, tint = P.mute) },
                shape = CircleShape, colors = glassFieldColors(),
            )
        }
        if (key.isEmpty()) item { Empty("Search songs, artists and people") }
        else if (people.isEmpty() && songs.isEmpty()) item { Empty("No results") }
        if (people.isNotEmpty()) {
            item { SectionTitle("People") }
            items(people, key = { "u" + it.id }) { PersonRow(it) { open(it.id) } }
        }
        if (songs.isNotEmpty()) {
            item { SectionTitle("Songs") }
            items(songs, key = { "s" + it.id }) { SongRow(vm, it, songs) }
        }
    }
}

@Composable
fun LibraryTab(vm: MainVM, bottom: androidx.compose.ui.unit.Dp) {
    val liked = vm.songs.filter { it.liked }
    SongList(vm, liked, bottom) {
        Column(Modifier.padding(16.dp)) {
            Text("Liked songs", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("${liked.size} songs", color = P.mute, modifier = Modifier.padding(top = 2.dp, bottom = 12.dp))
            if (liked.isNotEmpty()) GradButton("Play all", { vm.play(liked, 0) }, icon = Icons.Default.PlayArrow)
        }
    }
}

// ============================ Mini player ============================

@Composable
fun MiniPlayer(vm: MainVM, s: Song, open: () -> Unit) {
    val p = vm.player
    val accent by animateColorAsState(rememberAccent(s.cover), tween(700), label = "mini")
    Box(
        Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp)
            .glass(20.dp, Color(0xEE16102C)).clickable { open() },
    ) {
        Row(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Cover(s.cover, Modifier.size(46.dp), 12.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium, fontSize = 15.sp)
                Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, color = P.mute)
            }
            IconButton({ vm.toggleLike(s) }) {
                Icon(if (s.liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Like", tint = if (s.liked) P.pink else Color(0xFFD8CCFF))
            }
            IconButton({ p.toggle() }) { Icon(if (p.playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Play/Pause", tint = Color(0xFFD8CCFF)) }
            IconButton({ p.next() }) { Icon(Icons.Default.SkipNext, "Next", tint = Color(0xFFD8CCFF)) }
        }
        val frac = if (p.dur > 0) (p.pos.toFloat() / p.dur).coerceIn(0f, 1f) else 0f
        Box(Modifier.align(Alignment.BottomStart).padding(horizontal = 18.dp).fillMaxWidth().height(2.dp).background(Color(0x22FFFFFF))) {
            Box(Modifier.fillMaxHeight().fillMaxWidth(frac).background(Brush.horizontalGradient(listOf(accent, P.p2))))
        }
    }
}

// ============================ Dynamic color ============================

/** رنگ غالب کاور (Palette) — برای تم داینامیک پلیر */
@Composable
fun rememberAccent(url: String): Color {
    val ctx = LocalContext.current
    val st = produceState(P.p, url) {
        if (url.isEmpty()) { value = P.p; return@produceState }
        val r = runCatching {
            ctx.imageLoader.execute(ImageRequest.Builder(ctx).data(url).size(128).allowHardware(false).build())
        }.getOrNull()
        val bmp = ((r as? SuccessResult)?.drawable as? BitmapDrawable)?.bitmap
        if (bmp != null) {
            val pal = withContext(Dispatchers.Default) { Palette.from(bmp).maximumColorCount(16).generate() }
            val sw = pal.vibrantSwatch ?: pal.lightVibrantSwatch ?: pal.mutedSwatch ?: pal.dominantSwatch
            var c = sw?.let { Color(it.rgb) } ?: P.p
            if (c.luminance() < 0.12f) c = lerp(c, Color.White, 0.35f)
            value = c
        }
    }
    return st.value
}

// ============================ Full player ============================

@Composable
fun NowPlaying(vm: MainVM, onClose: () -> Unit) {
    val p = vm.player
    val s = vm.songs.firstOrNull { it.id == p.currentId }
    if (s == null) { LaunchedEffect(Unit) { onClose() }; return }
    val ctx = LocalContext.current
    val openProfile = LocalOpenProfile.current
    val a1 by animateColorAsState(rememberAccent(s.cover), tween(900), label = "accent")
    var drag by remember { mutableStateOf<Float?>(null) }
    var showComments by remember { mutableStateOf(false) }
    var showLyrics by remember { mutableStateOf(false) }
    var dy by remember { mutableFloatStateOf(0f) }
    val dur = p.dur.coerceAtLeast(1L)
    val frac = drag ?: (p.pos.toFloat() / dur).coerceIn(0f, 1f)
    val coverScale by animateFloatAsState(if (p.playing) 1f else 0.9f, spring(dampingRatio = 0.55f, stiffness = 300f), label = "cs")
    val uploader = vm.userById(s.uid)
    val dragClose = Modifier.pointerInput(Unit) {
        detectVerticalDragGestures(
            onDragEnd = { if (dy > 260f) onClose() else dy = 0f },
            onDragCancel = { dy = 0f },
        ) { _, d -> dy = (dy + d).coerceAtLeast(0f) }
    }

    Box(Modifier.fillMaxSize().background(P.bg).offset { IntOffset(0, dy.roundToInt()) }) {
        // پس‌زمینه‌ی تار از کاور + رنگ داینامیک
        if (s.cover.isNotEmpty()) AsyncImage(
            s.cover, null, Modifier.fillMaxSize().blur(70.dp).alpha(0.55f), contentScale = ContentScale.Crop,
        )
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(a1.copy(alpha = 0.55f), Color(0xCC0A0716), P.bg))))

        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                .padding(horizontal = 24.dp).verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(Modifier.fillMaxWidth().then(dragClose), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClose) { Icon(Icons.Default.KeyboardArrowDown, "Close", Modifier.size(32.dp)) }
                Text("NOW PLAYING", Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 12.sp, letterSpacing = 3.sp, color = P.mute)
                Spacer(Modifier.size(48.dp))
            }
            Spacer(Modifier.height(8.dp))
            Box(
                Modifier.fillMaxWidth().aspectRatio(1f).graphicsLayer { scaleX = coverScale; scaleY = coverScale }
                    .shadow(36.dp, RoundedCornerShape(24.dp), ambientColor = a1, spotColor = a1)
                    .then(dragClose),
            ) { Cover(s.cover, Modifier.fillMaxSize(), 24.dp) }
            Spacer(Modifier.height(24.dp))

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(s.title, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    if (s.artist.isNotBlank()) Text(s.artist, color = P.soft, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (s.album.isNotBlank()) Text("Album · ${s.album}", color = P.mute, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (s.user.isNotBlank()) Text(
                        "Uploaded by ${s.user}", color = P.mute, fontSize = 13.sp,
                        modifier = Modifier.padding(top = 4.dp).clickable { onClose(); openProfile(s.uid) },
                    )
                }
                if (uploader != null && !s.mine && s.uid.isNotEmpty()) {
                    if (uploader.fme) GhostButton("Following", { vm.toggleFollow(uploader) })
                    else GradButton("Follow", { vm.toggleFollow(uploader) })
                }
            }

            Spacer(Modifier.height(20.dp))
            Wave(s.id, frac, p.playing, a1) { f -> p.seek((f * dur).toLong()) }
            Slider(
                value = frac,
                onValueChange = { drag = it },
                onValueChangeFinished = { drag?.let { p.seek((it * dur).toLong()) }; drag = null },
                colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = a1, inactiveTrackColor = Color(0x33FFFFFF)),
            )
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                Text(fmt(drag?.let { (it * dur).toLong() } ?: p.pos), fontSize = 12.sp, color = P.mute)
                Text(fmt(p.dur), fontSize = 12.sp, color = P.mute)
            }

            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton({ p.prev() }, Modifier.size(60.dp)) { Icon(Icons.Default.SkipPrevious, "Prev", Modifier.size(38.dp)) }
                Box(
                    Modifier.padding(horizontal = 18.dp).size(76.dp)
                        .shadow(20.dp, CircleShape, ambientColor = a1, spotColor = a1)
                        .clip(CircleShape).background(Brush.linearGradient(listOf(a1, P.p2)))
                        .clickable { p.toggle() },
                    Alignment.Center,
                ) { Icon(if (p.playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Play/Pause", Modifier.size(42.dp), tint = Color.White) }
                IconButton({ p.next() }, Modifier.size(60.dp)) { Icon(Icons.Default.SkipNext, "Next", Modifier.size(38.dp)) }
            }

            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly, Alignment.CenterVertically) {
                ActionBtn(if (s.liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "${s.likes}", if (s.liked) P.pink else P.mute) { vm.toggleLike(s) }
                ActionBtn(Icons.Default.ChatBubbleOutline, "${s.comments}", P.mute) { showComments = true }
                if (s.lyrics.isNotBlank()) ActionBtn(Icons.Default.Lyrics, "Lyrics", P.mute) { showLyrics = true }
                ActionBtn(Icons.Default.Share, "Share", P.mute) {
                    val i = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, "${s.title} — ${s.artist}\n${BASE}index.php?s=${s.id}")
                    }
                    ctx.startActivity(Intent.createChooser(i, null))
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
    if (showComments) CommentsSheet(vm, s) { showComments = false }
    if (showLyrics) ModalBottomSheet({ showLyrics = false }, containerColor = P.card, contentColor = P.ink) {
        Column(Modifier.padding(horizontal = 24.dp).navigationBarsPadding()) {
            Text(s.title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Text(s.lyrics, Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()), lineHeight = 26.sp)
            Spacer(Modifier.height(20.dp))
        }
    }
}

@Composable
private fun ActionBtn(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, tint: Color, click: () -> Unit) {
    Row(
        Modifier.clip(CircleShape).clickable(onClick = click).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, label, Modifier.size(22.dp), tint = tint)
        Spacer(Modifier.width(6.dp))
        Text(label, fontSize = 14.sp, color = P.mute)
    }
}

/** ویوفرم ۴۰ میله‌ای: تپ = seek، هنگام پخش می‌رقصد */
@Composable
fun Wave(seed: String, progress: Float, playing: Boolean, accent: Color, onSeek: (Float) -> Unit) {
    val n = 40
    val base = remember(seed) { val r = java.util.Random(seed.hashCode().toLong()); List(n) { 0.25f + r.nextFloat() * 0.75f } }
    val t = rememberInfiniteTransition(label = "wave").animateFloat(
        0f, 1f, infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "t",
    )
    Canvas(
        Modifier.fillMaxWidth().height(56.dp).pointerInput(Unit) {
            detectTapGestures { o -> onSeek((o.x / size.width).coerceIn(0f, 1f)) }
        },
    ) {
        val gap = 4.dp.toPx()
        val bw = (size.width - gap * (n - 1)) / n
        for (i in 0 until n) {
            val wob = if (playing) 0.85f + 0.15f * sin(t.value * 2f * PI.toFloat() + i * 0.6f) else 1f
            val h = size.height * base[i] * wob
            val done = (i + 0.5f) / n <= progress
            drawRoundRect(
                if (done) accent else Color.White.copy(alpha = 0.22f),
                Offset(i * (bw + gap), (size.height - h) / 2f), Size(bw, h), CornerRadius(bw / 2f),
            )
        }
    }
}

// ============================ Comments ============================

@Composable
fun CommentsSheet(vm: MainVM, s: Song, close: () -> Unit) {
    var list by remember { mutableStateOf<List<Comment>>(emptyList()) }
    var text by remember { mutableStateOf("") }
    var reload by remember { mutableIntStateOf(0) }
    LaunchedEffect(s.id, reload) { list = runCatching { vm.comments(s.id) }.getOrDefault(emptyList()) }
    ModalBottomSheet(close, containerColor = P.card, contentColor = P.ink) {
        Column(Modifier.padding(horizontal = 20.dp).navigationBarsPadding().imePadding()) {
            Text("Comments", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            if (list.isEmpty()) Empty("No comments yet")
            LazyColumn(Modifier.heightIn(max = 340.dp)) {
                items(list, key = { it.id }) {
                    Column(Modifier.padding(vertical = 8.dp)) {
                        Text(it.user, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = P.soft)
                        Text(it.text)
                    }
                }
            }
            OutlinedTextField(
                text, { text = it }, Modifier.fillMaxWidth().padding(vertical = 10.dp),
                placeholder = { Text("Write a comment…", color = P.mute) },
                shape = CircleShape, colors = glassFieldColors(),
                trailingIcon = {
                    IconButton({
                        val t = text.trim()
                        if (t.isNotEmpty()) vm.postComment(s.id, t) { text = ""; reload++ }
                    }) { Icon(Icons.Default.Send, "Send", tint = P.p) }
                },
            )
        }
    }
}
