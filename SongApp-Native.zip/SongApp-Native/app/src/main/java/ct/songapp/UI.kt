@file:OptIn(ExperimentalMaterial3Api::class)

package ct.songapp

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

val LocalOpenProfile = compositionLocalOf<(String) -> Unit> { {} }

@Composable
fun MusicTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(
        primary = Color(0xFFA78BFA), onPrimary = Color(0xFF1B0B3A),
        background = Color(0xFF0B0B10), onBackground = Color(0xFFECECF1),
        surface = Color(0xFF14141C), onSurface = Color(0xFFECECF1),
        surfaceVariant = Color(0xFF23232F), onSurfaceVariant = Color(0xFF9A9AAE),
    ),
    content = content,
)

@Composable
fun Root(vm: MainVM) {
    val ctx = LocalContext.current
    LaunchedEffect(vm.toast) {
        vm.toast?.let { Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show(); vm.toast = null }
    }
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        when {
            vm.booting -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
            vm.token == null -> LoginScreen(vm)
            else -> MainScreen(vm)
        }
    }
}

@Composable
fun LoginScreen(vm: MainVM) {
    var u by remember { mutableStateOf("") }
    var p by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().padding(32.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(Icons.Default.MusicNote, null, Modifier.size(72.dp), tint = MaterialTheme.colorScheme.primary)
        Text("Music", style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(u, { u = it.trim() }, Modifier.fillMaxWidth(), label = { Text("Username") }, singleLine = true)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            p, { p = it }, Modifier.fillMaxWidth(), label = { Text("Password") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        )
        vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp)) }
        Spacer(Modifier.height(16.dp))
        val ok = !vm.busy && u.isNotEmpty() && p.isNotEmpty()
        Button({ vm.auth(false, u, p) }, Modifier.fillMaxWidth(), enabled = ok) {
            if (vm.busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Text("Log in")
        }
        TextButton({ vm.auth(true, u, p) }, enabled = ok) { Text("Create account") }
    }
}

@Composable
fun Cover(url: String, modifier: Modifier) {
    Box(
        modifier.clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
        Alignment.Center,
    ) {
        if (url.isNotEmpty()) AsyncImage(url, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(Icons.Default.MusicNote, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

fun fmt(ms: Long): String { val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60) }

private val TITLES = listOf("Home", "Search", "NFT", "Liked", "Profile")

@Composable
fun MainScreen(vm: MainVM) {
    var tab by remember { mutableIntStateOf(0) }
    var showPlayer by remember { mutableStateOf(false) }
    var profileId by remember { mutableStateOf<String?>(null) }
    var storyUid by remember { mutableStateOf<String?>(null) }
    val p = vm.player
    LaunchedEffect(p.playing) { while (p.playing) { p.tick(); delay(500) } }
    val cur = vm.songs.firstOrNull { it.id == p.currentId }

    CompositionLocalProvider(LocalOpenProfile provides { profileId = it }) {
        Box(Modifier.fillMaxSize()) {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = { Text(TITLES[tab]) },
                        actions = {
                            IconButton({ if (tab == 2) vm.loadNft() else vm.refresh() }) { Icon(Icons.Default.Refresh, "Refresh") }
                        },
                    )
                },
                bottomBar = {
                    Column {
                        if (cur != null) MiniPlayer(vm, cur) { showPlayer = true }
                        NavigationBar {
                            listOf(Icons.Default.Home, Icons.Default.Search, Icons.Default.Diamond, Icons.Default.Favorite, Icons.Default.Person)
                                .forEachIndexed { i, ic ->
                                    NavigationBarItem(tab == i, { tab = i; profileId = null }, { Icon(ic, TITLES[i]) }, label = { Text(TITLES[i]) })
                                }
                        }
                    }
                },
            ) { pad ->
                Box(Modifier.padding(pad)) {
                    Column {
                        if (vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth())
                        when (tab) {
                            0 -> SongList(vm, vm.songs) { StoriesRow(vm) { storyUid = it } }
                            1 -> SearchTab(vm)
                            2 -> NftTab(vm)
                            3 -> SongList(vm, vm.songs.filter { it.liked })
                            else -> vm.me?.let { ProfileList(vm, it, true) }
                        }
                    }
                    profileId?.let { id ->
                        BackHandler { profileId = null }
                        ProfileScreen(vm, id) { profileId = null }
                    }
                }
            }
            if (showPlayer) {
                BackHandler { showPlayer = false }
                NowPlaying(vm) { showPlayer = false }
            }
            storyUid?.let { uid ->
                BackHandler { storyUid = null }
                StoryViewer(vm, uid) { storyUid = null }
            }
        }
    }
}

@Composable
fun SongList(vm: MainVM, list: List<Song>, header: (@Composable () -> Unit)? = null) {
    LazyColumn(Modifier.fillMaxSize()) {
        header?.let { h -> item { h() } }
        if (list.isEmpty()) item {
            Box(Modifier.fillMaxWidth().padding(48.dp), Alignment.Center) {
                Text("چیزی برای نمایش نیست", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        items(list, key = { it.id }) { SongRow(vm, it, list) }
    }
}

@Composable
fun SongRow(vm: MainVM, s: Song, list: List<Song>) {
    val active = vm.player.currentId == s.id
    val openProfile = LocalOpenProfile.current
    Row(
        Modifier.fillMaxWidth().clickable { vm.play(list, list.indexOf(s)) }
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Cover(s.cover, Modifier.size(52.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium,
                color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
            )
            Row {
                if (s.artist.isNotBlank()) Text(
                    s.artist, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f, fill = false),
                )
                if (s.artist.isNotBlank() && s.user.isNotBlank()) Text(" • ", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (s.user.isNotBlank()) Text(
                    s.user, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.primary, modifier = Modifier.clickable { openProfile(s.uid) },
                )
            }
        }
        IconButton({ vm.toggleLike(s) }) {
            Icon(
                if (s.liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Like",
                tint = if (s.liked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
fun SearchTab(vm: MainVM) {
    var q by remember { mutableStateOf("") }
    val open = LocalOpenProfile.current
    val key = q.trim()
    val songs = if (key.isEmpty()) emptyList() else vm.songs.filter {
        listOf(it.title, it.artist, it.album, it.user).any { f -> f.contains(key, ignoreCase = true) }
    }
    val people = if (key.isEmpty()) emptyList() else vm.users.filter {
        it.name.contains(key, ignoreCase = true) || it.un.contains(key, ignoreCase = true)
    }
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            OutlinedTextField(
                q, { q = it }, Modifier.fillMaxWidth().padding(16.dp), singleLine = true,
                placeholder = { Text("Songs, artists, people…") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
            )
        }
        if (people.isNotEmpty()) {
            item { Text("People", Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.titleSmall) }
            items(people, key = { "u" + it.id }) { PersonRow(it) { open(it.id) } }
        }
        if (songs.isNotEmpty()) {
            item { Text("Songs", Modifier.padding(horizontal = 16.dp, vertical = 4.dp), style = MaterialTheme.typography.titleSmall) }
            items(songs, key = { "s" + it.id }) { SongRow(vm, it, songs) }
        }
    }
}

@Composable
fun MiniPlayer(vm: MainVM, s: Song, open: () -> Unit) {
    val p = vm.player
    Surface(Modifier.fillMaxWidth().clickable { open() }, color = MaterialTheme.colorScheme.surfaceVariant) {
        Column {
            LinearProgressIndicator(
                progress = { if (p.dur > 0) (p.pos.toFloat() / p.dur).coerceIn(0f, 1f) else 0f },
                Modifier.fillMaxWidth().height(2.dp),
            )
            Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Cover(s.cover, Modifier.size(40.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                    Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton({ p.toggle() }) { Icon(if (p.playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Play/Pause") }
                IconButton({ p.next() }) { Icon(Icons.Default.SkipNext, "Next") }
            }
        }
    }
}

@Composable
fun NowPlaying(vm: MainVM, onClose: () -> Unit) {
    val p = vm.player
    val s = vm.songs.firstOrNull { it.id == p.currentId }
    if (s == null) { LaunchedEffect(Unit) { onClose() }; return }
    var drag by remember { mutableStateOf<Float?>(null) }
    var showComments by remember { mutableStateOf(false) }
    var showLyrics by remember { mutableStateOf(false) }
    val dur = p.dur.coerceAtLeast(1L)

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
                .padding(horizontal = 24.dp).verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(Modifier.fillMaxWidth()) {
                IconButton(onClose) { Icon(Icons.Default.KeyboardArrowDown, "Close", Modifier.size(32.dp)) }
            }
            Cover(s.cover, Modifier.fillMaxWidth().aspectRatio(1f))
            Spacer(Modifier.height(24.dp))
            Text(s.title, style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center, maxLines = 2)
            Text(s.artist, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
            Spacer(Modifier.height(16.dp))
            Slider(
                value = drag ?: (p.pos.toFloat() / dur).coerceIn(0f, 1f),
                onValueChange = { drag = it },
                onValueChangeFinished = { drag?.let { p.seek((it * dur).toLong()) }; drag = null },
            )
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                Text(fmt(drag?.let { (it * dur).toLong() } ?: p.pos), style = MaterialTheme.typography.bodySmall)
                Text(fmt(p.dur), style = MaterialTheme.typography.bodySmall)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton({ p.prev() }, Modifier.size(56.dp)) { Icon(Icons.Default.SkipPrevious, "Prev", Modifier.size(36.dp)) }
                FilledIconButton({ p.toggle() }, Modifier.padding(horizontal = 16.dp).size(72.dp)) {
                    Icon(if (p.playing) Icons.Default.Pause else Icons.Default.PlayArrow, "Play/Pause", Modifier.size(40.dp))
                }
                IconButton({ p.next() }, Modifier.size(56.dp)) { Icon(Icons.Default.SkipNext, "Next", Modifier.size(36.dp)) }
            }
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton({ vm.toggleLike(s) }) {
                    Icon(
                        if (s.liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Like",
                        tint = if (s.liked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                    )
                }
                Text("${s.likes}")
                Spacer(Modifier.width(16.dp))
                IconButton({ showComments = true }) { Icon(Icons.Default.ChatBubbleOutline, "Comments") }
                Text("${s.comments}")
                if (s.lyrics.isNotBlank()) {
                    Spacer(Modifier.width(16.dp))
                    IconButton({ showLyrics = true }) { Icon(Icons.Default.Lyrics, "Lyrics") }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
    if (showComments) CommentsDialog(vm, s) { showComments = false }
    if (showLyrics) AlertDialog(
        onDismissRequest = { showLyrics = false },
        confirmButton = { TextButton({ showLyrics = false }) { Text("Close") } },
        title = { Text(s.title) },
        text = { Text(s.lyrics, Modifier.verticalScroll(rememberScrollState())) },
    )
}

@Composable
fun CommentsDialog(vm: MainVM, s: Song, close: () -> Unit) {
    var list by remember { mutableStateOf<List<Comment>>(emptyList()) }
    var text by remember { mutableStateOf("") }
    var reload by remember { mutableIntStateOf(0) }
    LaunchedEffect(s.id, reload) { list = runCatching { vm.comments(s.id) }.getOrDefault(emptyList()) }
    AlertDialog(
        onDismissRequest = close,
        confirmButton = { TextButton(close) { Text("Close") } },
        title = { Text("Comments") },
        text = {
            Column {
                LazyColumn(Modifier.heightIn(max = 280.dp)) {
                    items(list, key = { it.id }) {
                        Column(Modifier.padding(vertical = 6.dp)) {
                            Text(it.user, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                            Text(it.text)
                        }
                    }
                }
                OutlinedTextField(
                    text, { text = it }, Modifier.fillMaxWidth().padding(top = 8.dp),
                    placeholder = { Text("Write a comment…") },
                    trailingIcon = {
                        IconButton({
                            val t = text.trim()
                            if (t.isNotEmpty()) vm.postComment(s.id, t) { text = ""; reload++ }
                        }) { Icon(Icons.Default.Send, "Send") }
                    },
                )
            }
        },
    )
}
